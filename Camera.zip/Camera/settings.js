var settings<%albumNumber%> = {
	thumbnails: true, 			// [true, false]
	time: 3000, 				// milliseconds between the end of the sliding effect and the start of the nex one
	transPeriod: 1500, 			// length of the sliding effect in milliseconds
	loader: 'bar', 				// [pie, bar, none] (even if you choose "pie", old browsers like IE8- can't display it... they will display always a loading bar)
	pagination: false, 			// [true, false]
	opacityOnGrid: false, 		// [true, false] Decide to apply a fade effect to blocks and slices: if your slideshow is fullscreen or simply big, I recommend to set it false to have a smoother effect
	hover: true, 				// [true, false] Pause on state hover. Not available for mobile devices the path to the image folder (it serves for the blank.gif, when you want to display videos)
	height: 'auto', 			// If you want a 100% responsive look-and-feel, do not change
	alignment: 'center',		// [topLeft, topCenter, topRight, centerLeft, center, centerRight, bottomLeft, bottomCenter, bottomRight]
	autoAdvance: true,			// [true, false]
	mobileAutoAdvance: true,	//Auto-advancing for mobile devices [true, false]
	barDirection: 'leftToRight',// ['leftToRight', 'rightToLeft', 'topToBottom', 'bottomToTop']
	barPosition: 'bottom',		// ['left', 'right', 'top', 'bottom']
	cols: 6,
	easing: 'easeInOutExpo',	// for the complete list http://jqueryui.com/demos/effect/easing.html
	mobileEasing: '',			// leave empty if you want to display the same easing on mobile devices and on desktop etc.
	fx: 'random',				// ['random','simpleFade', 'curtainTopLeft', 'curtainTopRight', 'curtainBottomLeft', 'curtainBottomRight', 'curtainSliceLeft', 'curtainSliceRight', 'blindCurtainTopLeft', 'blindCurtainTopRight', 'blindCurtainBottomLeft', 'blindCurtainBottomRight', 'blindCurtainSliceBottom', 'blindCurtainSliceTop', 'stampede', 'mosaic', 'mosaicReverse', 'mosaicRandom', 'mosaicSpiral', 'mosaicSpiralReverse', 'topLeftBottomRight', 'bottomRightTopLeft', 'bottomLeftTopRight', 'bottomLeftTopRight']
								// N.B.: you can also use more than one effect, just separate them with commas: 'simpleFade, scrollRight, scrollBottom'
	mobileFx: '',				// leave empty if you want to display the same effect on mobile devices and on desktop etc.
	gridDifference: 250,		// to make the grid blocks slower than the slices, this value must be smaller than transPeriod
	loaderColor: '#eeeeee',
	loaderBgColor: '#222222',
	loaderOpacity: .8,			// [0, .1, .2, .3, .4, .5, .6, .7, .8, .9, 1] 1 = not transparent
	loaderPadding: 2,			// how many empty pixels you want to display between the loader and its background
	loaderStroke: 7,			// the thickness both of the pie loader and of the bar loader. Remember: for the pie, the loader thickness must be less than a half of the pie diameter
	minHeight: '200px',			// you can also leave it blank
	navigationHover: true,		// if true the navigation button (prev, next and play/stop buttons) will be visible on hover state only, if false they will be visible always
	mobileNavHover: true,		// same as above, but only for mobile devices
	overlayer: true,			// [true, false] Decide to put a layer on the images to prevent the users grab them simply by clicking the right button of their mouse (.camera_overlayer)
	pauseOnClick: true,			// [true, false] It stops the slideshow when you click the sliders
	pieDiameter: 38,
	piePosition: 'rightTop',	// ['rightTop', 'leftTop', 'leftBottom', 'rightBottom']
	portrait: false,			// [true, false] Select true if you don't want that your images are cropped
	rows: 4,
	slicedCols: 12,				// if 0 the same value of cols
	slicedRows: 8,				// if 0 the same value of rows
	slideOn: 'random',			// [next, prev, random] decide if the transition effect will be applied to the current (prev) or the next slide
	imagePath: 'img/',			// do not change

// CALLBACKS
onStartLoading: function() { },		// this callback is invoked when the image on a slide start loading
onLoaded: function() { },			// this callback is invoked when the image on a slide has completely loaded
onStartTransition: function() { },	// this callback is invoked when the transition effect starts
onEndTransition: function() { }		// this callback is invoked when the transition effect ends
};

var theme = 'camera_amber_skin';
// Defined thems, can also be blank
//   camera_amber_skin |  camera_ash_skin  |  camera_azure_skin  |  camera_beige_skin  |  camera_black_skin  |  camera_blue_skin  |  camera_brown_skin  |  camera_burgundy_skin  |  camera_charcoal_skin  |  camera_chocolate_skin  |  camera_coffee_skin  |  camera_cyan_skin  |  camera_fuchsia_skin  |  camera_gold_skin  |  camera_green_skin  |  camera_grey_skin  |  camera_indigo_skin  |  camera_khaki_skin  |  camera_lime_skin  |  camera_magenta_skin  |  camera_maroon_skin  |  camera_orange_skin  |  camera_olive_skin  |  camera_pink_skin  |  camera_pistachio_skin  |  camera_pink_skin  |  camera_red_skin  |  camera_tangerine_skin  |  camera_turquoise_skin  |  camera_violet_skin  |  camera_white_skin  |  camera_yellow_skin';